//
//  ViewController.swift
//  ImageBrowser
//
//  Created by maoqiang on 4/20/19.
//  Copyright © 2019 maoqiang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.addImageView()
        
    }
    
    private func addImageView(){
        for (i,url) in imageUrls.enumerated() {
            let imageView = WDImageView()
            imageView.setImage(imageUrl: url, thumbnailUrl: url)
            
            let row = i / 3
            let column = i % 3
            
            let w: CGFloat = (kScreenWidth_s)/3
            let h: CGFloat = w
            
            let x: CGFloat = CGFloat(column)*w
            let y: CGFloat = CGFloat(row)*h + 200
            
            imageView.frame = CGRect(x: x, y: y, width: w, height: h)
            self.view.addSubview(imageView)
        }
    }
    
    let imageUrls: [String] = [
        "https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=234634259,4236876085&fm=27&gp=0.jpg",
        "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2259376396,2250852130&fm=27&gp=0.jpg",
        "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2153937626,1074119156&fm=27&gp=0.jpg",
        "https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=3166167724,322082273&fm=27&gp=0.jpg",
    ]

}

